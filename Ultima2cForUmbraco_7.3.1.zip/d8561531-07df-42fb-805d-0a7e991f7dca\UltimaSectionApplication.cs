﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using umbraco.businesslogic;
using umbraco.interfaces;
using Ultima;

namespace Ultima
{
	[Application("ultima", "Ultima", "icon-equalizer", 16)]
	public class UltimaApplication : IApplication
	{
		
	}
}